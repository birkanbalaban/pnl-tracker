import requests
from datetime import datetime

class TelegramNotifier:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.base_url = f"https://api.telegram.org/bot{token}"

    def send_message(self, message):
        """Telegram üzerinden mesaj gönderir"""
        url = f"{self.base_url}/sendMessage"
        payload = {
            'chat_id': self.chat_id,
            'text': message,
            'parse_mode': 'Markdown'
        }
        try:
            response = requests.post(url, data=payload)
            response.raise_for_status()
            return True
        except Exception as e:
            print(f"Telegram bildirim hatası: {e}")
            return False

    def send_pnl_alert(self, symbol, current_pnl, target_pnl, alarm_type):
        """PNL alarmı için özelleştirilmiş mesaj gönderir"""
        message = (
            f"🚨 *PNL Alarmı!*\n\n"
            f"Symbol: `{symbol}`\n"
            f"Hedef: `{target_pnl:.2f} USDT` ({alarm_type})\n"
            f"Mevcut PNL: `{current_pnl:.2f} USDT`\n"
            f"Zaman: `{datetime.now().strftime('%H:%M:%S')}`"
        )
        return self.send_message(message)

    def send_position_update(self, position_data):
        """Pozisyon güncellemesi için özelleştirilmiş mesaj gönderir"""
        message = (
            f"📊 *Pozisyon Güncellemesi*\n\n"
            f"Symbol: `{position_data['symbol']}`\n"
            f"PNL: `{position_data['pnl']:.2f} USDT`\n"
            f"ROE: `{position_data['roe']:.2f}%`\n"
            f"Mark Fiyat: `{position_data['mark_price']:.4f}`"
        )
        return self.send_message(message) 