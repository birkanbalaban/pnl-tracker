from telegram.ext import Application, CommandHandler
import asyncio
from datetime import datetime
import threading

class TelegramNotifier:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.app = None
        
        # Asenkron uygulama oluştur
        self.application = Application.builder().token(self.token).build()
        
        # Komutları kaydet
        self.application.add_handler(CommandHandler("start", self.cmd_start))
        self.application.add_handler(CommandHandler("help", self.cmd_help))
        self.application.add_handler(CommandHandler("pnl", self.cmd_pnl))
        self.application.add_handler(CommandHandler("positions", self.cmd_positions))
        self.application.add_handler(CommandHandler("threshold", self.cmd_threshold))
        
        # Bot'u başlat
        self.start_bot()
        
    def start_bot(self):
        """Bot'u başlat"""
        def run_bot():
            asyncio.set_event_loop(asyncio.new_event_loop())
            self.application.run_polling(allowed_updates=["message"])
            
        self.bot_thread = threading.Thread(target=run_bot, daemon=True)
        self.bot_thread.start()
        print("Telegram bot başlatıldı!")

    async def cmd_start(self, update, context):
        await update.message.reply_text(
            "🤖 PNL Tracker Bot'a Hoş Geldiniz!\n\n"
            "Komutları görmek için /help yazabilirsiniz."
        )

    async def cmd_help(self, update, context):
        await update.message.reply_text(
            "📋 Kullanılabilir komutlar:\n\n"
            "/threshold <değer> - Bildirim eşiğini değiştirir (USDT)\n"
            "/positions - Tüm aktif pozisyonları listeler\n"
            "/pnl - Güncel PNL durumunu gösterir\n"
            "/help - Bu yardım mesajını gösterir"
        )

    async def cmd_pnl(self, update, context):
        if not hasattr(self, 'app'):
            await update.message.reply_text("❌ Sistem henüz hazır değil!")
            return
            
        try:
            account = self.app.client.futures_account()
            total_pnl = float(account['totalUnrealizedProfit'])
            
            await update.message.reply_text(
                f"📊 Güncel PNL Durumu:\n"
                f"💰 Toplam PNL: {total_pnl:.2f} USDT\n"
                f"📈 En Yüksek: {self.app.high_pnl:.2f} USDT\n"
                f"📉 En Düşük: {self.app.low_pnl:.2f} USDT\n"
                f"⏰ Son Güncelleme: {datetime.now().strftime('%H:%M:%S')}"
            )
        except Exception as e:
            await update.message.reply_text(f"❌ Hata: {str(e)}")

    async def cmd_positions(self, update, context):
        if not hasattr(self, 'app'):
            await update.message.reply_text("❌ Sistem henüz hazır değil!")
            return
            
        try:
            positions = [p for p in self.app.client.futures_position_information() if float(p['positionAmt']) != 0]
            
            if not positions:
                await update.message.reply_text("❌ Aktif pozisyon bulunamadı!")
                return
                
            total_pnl = sum(float(p['unRealizedProfit']) for p in positions)
            await update.message.reply_text(
                f"📈 Pozisyon Özeti:\n"
                f"💰 Toplam PNL: {total_pnl:.2f} USDT\n"
                f"📊 Pozisyon Sayısı: {len(positions)}\n"
                f"⏰ Son Güncelleme: {datetime.now().strftime('%H:%M:%S')}"
            )
            
            for pos in positions:
                pnl = float(pos['unRealizedProfit'])
                margin = float(pos['isolatedWallet'])
                roi = (pnl / margin * 100) if margin > 0 else 0
                
                await update.message.reply_text(
                    f"🔍 {pos['symbol']} Detayları:\n"
                    f"💰 PNL: {pnl:.2f} USDT\n"
                    f"📊 ROI: {roi:.2f}%\n"
                    f"💵 Pozisyon: {float(pos['positionAmt']):.4f}\n"
                    f"💎 Mark Fiyat: {float(pos['markPrice']):.4f}\n"
                    f"🔒 Teminat: {margin:.2f} USDT"
                )
                
        except Exception as e:
            await update.message.reply_text(f"❌ Hata: {str(e)}")

    async def cmd_threshold(self, update, context):
        if not context.args:
            await update.message.reply_text("❌ Lütfen bir değer girin. Örnek: /threshold 5")
            return
            
        try:
            value = float(context.args[0])
            if value <= 0:
                await update.message.reply_text("❌ Değer 0'dan büyük olmalıdır!")
                return
                
            if hasattr(self, 'app'):
                self.app.threshold_var.set(str(value))
                await update.message.reply_text(f"✅ Bildirim eşiği {value} USDT olarak ayarlandı!")
            else:
                await update.message.reply_text("❌ Sistem henüz hazır değil!")
                
        except ValueError:
            await update.message.reply_text("❌ Geçersiz değer! Örnek: /threshold 5")

    async def _send_message(self, text):
        """Asenkron mesaj gönderme"""
        try:
            await self.application.bot.send_message(
                chat_id=self.chat_id,
                text=text
            )
            return True
        except Exception as e:
            print(f"Mesaj gönderme hatası: {e}")
            return False

    def send_message(self, text):
        """Normal mesaj gönderme"""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            loop.run_until_complete(self._send_message(text))
        finally:
            loop.close()

    def send_pnl_alert(self, symbol, current_pnl, target_pnl, alarm_type):
        """PNL alarm bildirimi"""
        message = (
            f"⚠️ PNL Alarmı!\n\n"
            f"{symbol} pozisyonu için {target_pnl} USDT {alarm_type.lower()} "
            f"hedefine ulaşıldı!\nMevcut PNL: {current_pnl:.2f} USDT"
        )
        self.send_message(message)

    def send_position_update(self, position_data):
        """Pozisyon güncelleme bildirimi"""
        message = (
            f"📈 Pozisyon Güncellemesi:\n"
            f"Symbol: {position_data['symbol']}\n"
            f"PNL: {position_data['pnl']:.2f} USDT\n"
            f"ROI: {position_data['roe']:.2f}%\n"
            f"Mark Fiyat: {position_data['mark_price']:.4f}"
        )
        self.send_message(message)